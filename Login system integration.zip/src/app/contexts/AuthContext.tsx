import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'student' | 'lecturer' | 'staff' | 'admin' | 'guest';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  studentId?: string;
  balance?: number;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  loginSSO: (email: string) => Promise<void>;
  loginGuest: (name: string, phone: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const mockUsers: Record<string, User & { password: string }> = {
  'student@hcmut.edu.vn': {
    id: '1',
    name: 'Nguyễn Văn A',
    email: 'student@hcmut.edu.vn',
    role: 'student',
    studentId: '2052001',
    balance: 150000,
    password: 'student123',
  },
  'lecturer@hcmut.edu.vn': {
    id: '2',
    name: 'TS. Trần Thị B',
    email: 'lecturer@hcmut.edu.vn',
    role: 'lecturer',
    balance: 0,
    password: 'lecturer123',
  },
  'staff@hcmut.edu.vn': {
    id: '3',
    name: 'Lê Văn C',
    email: 'staff@hcmut.edu.vn',
    role: 'staff',
    password: 'staff123',
  },
  'admin@hcmut.edu.vn': {
    id: '4',
    name: 'Phạm Thị D',
    email: 'admin@hcmut.edu.vn',
    role: 'admin',
    password: 'admin123',
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string) => {
    await new Promise(resolve => setTimeout(resolve, 800));

    const foundUser = mockUsers[email];
    if (foundUser && foundUser.password === password) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
    } else {
      throw new Error('Email hoặc mật khẩu không đúng');
    }
  };

  const loginSSO = async (email: string) => {
    await new Promise(resolve => setTimeout(resolve, 1000));

    const foundUser = mockUsers[email];
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
    } else {
      throw new Error('Tài khoản không tồn tại trong hệ thống HCMUT_SSO');
    }
  };

  const loginGuest = async (name: string, phone: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    setUser({
      id: `guest-${Date.now()}`,
      name,
      email: phone,
      role: 'guest',
    });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, loginSSO, loginGuest, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
